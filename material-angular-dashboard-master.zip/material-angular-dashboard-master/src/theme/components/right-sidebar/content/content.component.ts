import { Component } from '@angular/core';

@Component({
  selector: 'base-right-sidebar-content',
  template: '<ng-content></ng-content>',
})
export class RightSidebarContentComponent {
}
