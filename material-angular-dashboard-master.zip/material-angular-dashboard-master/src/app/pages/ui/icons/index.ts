export { IconsComponent } from './icons.component';
