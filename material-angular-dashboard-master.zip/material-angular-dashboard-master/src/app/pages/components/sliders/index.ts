export { SlidersComponent } from './sliders.component';
