export { BadgesComponent } from './badges.component';
