export { TooltipsComponent } from './tooltips.component';
