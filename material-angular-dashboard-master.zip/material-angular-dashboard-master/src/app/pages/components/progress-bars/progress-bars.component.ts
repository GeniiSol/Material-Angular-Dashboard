import { Component } from '@angular/core';

@Component({
  selector: 'app-progress-bars',
  templateUrl: './progress-bars.component.html',
})
export class ProgressBarsComponent { }
