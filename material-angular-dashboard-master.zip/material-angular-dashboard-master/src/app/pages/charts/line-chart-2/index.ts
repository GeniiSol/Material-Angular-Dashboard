export { LineChart2Component } from './line-chart-2.component';
export { LineChart2Service } from './line-chart-2.service';
